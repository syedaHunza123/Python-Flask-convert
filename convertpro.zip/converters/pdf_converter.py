from pathlib import Path
import shutil
import subprocess

from pypdf import PdfReader, PdfWriter


def _extract_pages(input_path: Path):
    try:
        try:
            import pymupdf as fitz
        except ImportError:
            import fitz
        document = fitz.open(str(input_path))
        return [page.get_text("text") for page in document]
    except ImportError:
        reader = PdfReader(str(input_path))
        return [page.extract_text() or "" for page in reader.pages]


def pdf_to_text(input_path: Path, output_path: Path) -> None:
    output_path.write_text("\n\n".join(_extract_pages(input_path)), encoding="utf-8")


def pdf_to_word(input_path: Path, output_path: Path) -> None:
    try:
        from docx import Document
    except ImportError as exc:
        raise RuntimeError("PDF to Word requires python-docx. Install the listed requirements first.") from exc
    document = Document()
    for index, text in enumerate(_extract_pages(input_path)):
        if index:
            document.add_page_break()
        for paragraph in text.splitlines():
            if paragraph.strip():
                document.add_paragraph(paragraph)
    document.save(str(output_path))


def pdf_to_image(input_path: Path, output_dir: Path, extension: str) -> list[Path]:
    try:
        try:
            import pymupdf as fitz
        except ImportError:
            import fitz
    except ImportError as exc:
        raise RuntimeError("PDF to image requires PyMuPDF. Install the listed requirements first.") from exc
    document = fitz.open(str(input_path))
    outputs = []
    for index, page in enumerate(document, 1):
        pixmap = page.get_pixmap(matrix=fitz.Matrix(1.6, 1.6), alpha=False)
        path = output_dir / f"{input_path.stem}-page-{index}.{extension}"
        pixmap.save(str(path))
        outputs.append(path)
    return outputs


def images_to_pdf(input_paths: list[Path], output_path: Path) -> None:
    from PIL import Image
    images = []
    for path in input_paths:
        image = Image.open(path).convert("RGB")
        images.append(image)
    if not images:
        raise RuntimeError("Add at least one image to create a PDF.")
    images[0].save(str(output_path), save_all=True, append_images=images[1:])


def merge_pdfs(input_paths: list[Path], output_path: Path) -> None:
    writer = PdfWriter()
    for path in input_paths:
        reader = PdfReader(str(path))
        for page in reader.pages:
            writer.add_page(page)
    with output_path.open("wb") as handle:
        writer.write(handle)


def split_pdf(input_path: Path, output_dir: Path) -> list[Path]:
    reader = PdfReader(str(input_path))
    outputs = []
    for index, page in enumerate(reader.pages, 1):
        writer = PdfWriter()
        writer.add_page(page)
        page_path = output_dir / f"{input_path.stem}-page-{index}.pdf"
        with page_path.open("wb") as handle:
            writer.write(handle)
        outputs.append(page_path)
    return outputs


def rotate_pdf(input_path: Path, output_path: Path, angle: int = 90) -> None:
    reader = PdfReader(str(input_path))
    writer = PdfWriter()
    for page in reader.pages:
        page.rotate(angle)
        writer.add_page(page)
    with output_path.open("wb") as handle:
        writer.write(handle)


def compress_pdf(input_path: Path, output_path: Path) -> None:
    reader = PdfReader(str(input_path))
    writer = PdfWriter()
    for page in reader.pages:
        output_page = writer.add_page(page)
        output_page.compress_content_streams()
    with output_path.open("wb") as handle:
        writer.write(handle)


def office_to_pdf(input_path: Path, output_dir: Path) -> Path:
    if not shutil.which("libreoffice"):
        raise RuntimeError("Word to PDF requires LibreOffice. Install it and make sure `libreoffice` is on PATH.")
    output_dir.mkdir(parents=True, exist_ok=True)
    command = ["libreoffice", "--headless", "--convert-to", "pdf", "--outdir", str(output_dir), str(input_path)]
    result = subprocess.run(command, capture_output=True, text=True, timeout=90)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "LibreOffice could not convert this document.")
    output = output_dir / f"{input_path.stem}.pdf"
    if not output.exists():
        raise RuntimeError("LibreOffice did not produce a PDF output.")
    return output
