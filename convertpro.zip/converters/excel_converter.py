from pathlib import Path


def xlsx_to_csv(input_path: Path, output_path: Path) -> None:
    import pandas as pd
    frame = pd.read_excel(input_path)
    frame.to_csv(output_path, index=False)


def csv_to_xlsx(input_path: Path, output_path: Path) -> None:
    import pandas as pd
    frame = pd.read_csv(input_path)
    frame.to_excel(output_path, index=False)


def xlsx_to_html(input_path: Path, output_path: Path) -> None:
    import pandas as pd
    frame = pd.read_excel(input_path)
    output_path.write_text(frame.to_html(index=False, classes="convertpro-table", border=0), encoding="utf-8")
