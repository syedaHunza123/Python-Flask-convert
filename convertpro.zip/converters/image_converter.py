from pathlib import Path

from PIL import Image


def convert_image(input_path: Path, output_path: Path, target: str, quality: int = 88) -> None:
    image = Image.open(input_path)
    target = target.lower()
    if target in {"jpg", "jpeg"}:
        image = image.convert("RGB")
        image.save(output_path, format="JPEG", quality=quality, optimize=True)
    elif target == "png":
        image.save(output_path, format="PNG", optimize=True)
    elif target == "webp":
        image.save(output_path, format="WEBP", quality=quality, method=6)
    elif target == "bmp":
        image.save(output_path, format="BMP")
    elif target in {"tif", "tiff"}:
        image.save(output_path, format="TIFF", compression="tiff_deflate")
    else:
        raise ValueError(f"Image output format {target.upper()} is not supported.")


def resize_image(input_path: Path, output_path: Path, max_dimension: int = 1600) -> None:
    image = Image.open(input_path)
    image.thumbnail((max_dimension, max_dimension), Image.Resampling.LANCZOS)
    source_format = (image.format or input_path.suffix.lstrip('.')).upper()
    if source_format in {"JPG", "JPEG"}:
        image = image.convert("RGB")
        image.save(output_path, format="JPEG", quality=88, optimize=True)
    else:
        image.save(output_path, optimize=True)


def compress_image(input_path: Path, output_path: Path) -> None:
    image = Image.open(input_path)
    source = input_path.suffix.lower()
    if source in {".jpg", ".jpeg"}:
        image.convert("RGB").save(output_path, format="JPEG", quality=72, optimize=True, progressive=True)
    elif source == ".png":
        image.save(output_path, format="PNG", optimize=True)
    elif source == ".webp":
        image.save(output_path, format="WEBP", quality=72, method=6)
    else:
        image.save(output_path, optimize=True)
