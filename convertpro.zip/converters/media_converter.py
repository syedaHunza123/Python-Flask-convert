from pathlib import Path
import shutil
import subprocess


def media_convert(input_path: Path, output_path: Path, target: str, compress: bool = False) -> None:
    if not shutil.which("ffmpeg"):
        raise RuntimeError("Media conversion requires FFmpeg. Install FFmpeg and make sure `ffmpeg` is on PATH.")
    command = ["ffmpeg", "-y", "-i", str(input_path)]
    if target == "mp3":
        command += ["-vn", "-codec:a", "libmp3lame", "-q:a", "2"]
    elif target == "wav":
        command += ["-vn", "-codec:a", "pcm_s16le"]
    elif target == "mp4":
        command += ["-codec:v", "libx264", "-crf", "28" if compress else "23", "-preset", "fast", "-codec:a", "aac", "-b:a", "96k" if compress else "128k", "-movflags", "+faststart"]
    else:
        raise ValueError(f"Media output format {target.upper()} is not supported.")
    command.append(str(output_path))
    result = subprocess.run(command, capture_output=True, text=True, timeout=180)
    if result.returncode != 0:
        message = result.stderr.strip().splitlines()[-1] if result.stderr.strip() else "FFmpeg could not convert this media file."
        raise RuntimeError(message)
