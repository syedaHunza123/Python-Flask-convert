from html import escape
from pathlib import Path
import shutil
import subprocess


def docx_to_txt(input_path: Path, output_path: Path) -> None:
    try:
        from docx import Document
    except ImportError as exc:
        raise RuntimeError("DOCX conversion requires python-docx. Install the listed requirements first.") from exc
    document = Document(str(input_path))
    lines = [paragraph.text for paragraph in document.paragraphs]
    output_path.write_text("\n".join(lines), encoding="utf-8")


def txt_to_docx(input_path: Path, output_path: Path) -> None:
    try:
        from docx import Document
    except ImportError as exc:
        raise RuntimeError("TXT to DOCX requires python-docx. Install the listed requirements first.") from exc
    document = Document()
    for line in input_path.read_text(encoding="utf-8", errors="replace").splitlines():
        document.add_paragraph(line)
    document.save(str(output_path))


def docx_to_html(input_path: Path, output_path: Path) -> None:
    try:
        from docx import Document
    except ImportError as exc:
        raise RuntimeError("DOCX to HTML requires python-docx. Install the listed requirements first.") from exc
    document = Document(str(input_path))
    body = "\n".join(f"<p>{escape(paragraph.text)}</p>" for paragraph in document.paragraphs if paragraph.text.strip())
    output_path.write_text(f"<!doctype html><html><body>{body}</body></html>", encoding="utf-8")


def docx_to_pdf(input_path: Path, output_dir: Path) -> Path:
    if not shutil.which("libreoffice"):
        raise RuntimeError("DOCX to PDF requires LibreOffice. Install it and make sure `libreoffice` is on PATH.")
    command = ["libreoffice", "--headless", "--convert-to", "pdf", "--outdir", str(output_dir), str(input_path)]
    result = subprocess.run(command, capture_output=True, text=True, timeout=90)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "LibreOffice could not convert this document.")
    output = output_dir / f"{input_path.stem}.pdf"
    if not output.exists():
        raise RuntimeError("LibreOffice did not produce a PDF output.")
    return output
