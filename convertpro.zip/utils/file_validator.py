from pathlib import Path

from config import ALLOWED_EXTENSIONS, TOOL_BY_ID


def extension_for(filename: str) -> str:
    return Path(filename or "").suffix.lower().lstrip(".")


def is_allowed_filename(filename: str) -> bool:
    return bool(filename and extension_for(filename) in ALLOWED_EXTENSIONS)


def get_tool(tool_id: str):
    tool = TOOL_BY_ID.get(tool_id)
    if not tool:
        raise ValueError("That conversion tool is not available.")
    return tool


def validate_for_tool(filename: str, tool_id: str) -> tuple[str, dict]:
    source = extension_for(filename)
    if not source or source not in ALLOWED_EXTENSIONS:
        raise ValueError(f"{source.upper() or 'This'} files are not supported.")
    tool = get_tool(tool_id)
    if source not in tool["source"]:
        expected = ", ".join(ext.upper() for ext in tool["source"])
        raise ValueError(f"{tool['label']} accepts {expected} files, not {source.upper()}.")
    return source, tool


def validate_file_signature(path: Path, extension: str) -> None:
    header = path.read_bytes()[:16]
    signatures = {
        "pdf": header.startswith(b"%PDF"),
        "jpg": header.startswith(b"\xff\xd8\xff"),
        "jpeg": header.startswith(b"\xff\xd8\xff"),
        "png": header.startswith(b"\x89PNG\r\n\x1a\n"),
        "webp": header.startswith(b"RIFF") and header[8:12] == b"WEBP",
        "bmp": header.startswith(b"BM"),
        "tif": header.startswith((b"II*\x00", b"MM\x00*")),
        "tiff": header.startswith((b"II*\x00", b"MM\x00*")),
        "docx": header.startswith(b"PK"),
        "xlsx": header.startswith(b"PK"),
    }
    if extension in signatures and not signatures[extension]:
        raise ValueError(f"The uploaded content does not look like a valid {extension.upper()} file.")
