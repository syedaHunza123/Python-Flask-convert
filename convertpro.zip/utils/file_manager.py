import shutil
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from werkzeug.utils import secure_filename

from config import OUTPUT_ROOT, UPLOAD_ROOT


def create_job_folder() -> tuple[str, Path, Path]:
    job_id = uuid.uuid4().hex
    input_dir = UPLOAD_ROOT / job_id
    output_dir = OUTPUT_ROOT / job_id
    input_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    return job_id, input_dir, output_dir


def safe_input_path(input_dir: Path, filename: str) -> Path:
    clean_name = secure_filename(filename) or "upload"
    return input_dir / f"{uuid.uuid4().hex[:10]}_{clean_name}"


def output_path(output_dir: Path, original_name: str, extension: str) -> Path:
    stem = Path(secure_filename(original_name) or "converted").stem
    suffix = extension.lstrip('.')
    candidate = output_dir / f"{stem}.{suffix}"
    if not candidate.exists():
        return candidate
    return output_dir / f"{stem}-{uuid.uuid4().hex[:6]}.{suffix}"


def zip_outputs(job_id: str, files: list[Path]) -> Path:
    output_dir = OUTPUT_ROOT / job_id
    archive = output_dir / f"convertpro-{job_id[:8]}.zip"
    with ZipFile(archive, "w", ZIP_DEFLATED) as zip_file:
        for file_path in files:
            zip_file.write(file_path, arcname=file_path.name)
    return archive


def remove_job(job_id: str) -> None:
    for root in (UPLOAD_ROOT / job_id, OUTPUT_ROOT / job_id):
        if root.exists():
            shutil.rmtree(root, ignore_errors=True)


def cleanup_expired_jobs(max_age_hours: int = 24) -> None:
    cutoff = datetime.now(timezone.utc) - timedelta(hours=max_age_hours)
    for root in (UPLOAD_ROOT, OUTPUT_ROOT):
        for child in root.iterdir() if root.exists() else []:
            if not child.is_dir():
                continue
            modified = datetime.fromtimestamp(child.stat().st_mtime, tz=timezone.utc)
            if modified < cutoff:
                shutil.rmtree(child, ignore_errors=True)
