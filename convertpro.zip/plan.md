# ConvertPro – Implementation & Design Plan

## Implementation approach

ConvertPro is implemented as a modular Flask application with SQLite-backed conversion history. The server exposes page routes for the dashboard, tools catalog, and history view, plus JSON endpoints for conversion, history retrieval, and deletion. Uploaded files are stored in per-job temporary folders with secure filenames and unique identifiers; output downloads are authorized by job ID and cleaned up by an explicit cleanup helper.

The first delivery prioritizes the core user experience and real conversion seams: PDF, image, document, spreadsheet, and FFmpeg-backed media converters are separated into `converters/` modules. Optional system/library dependencies fail with a clear user-facing error instead of silently faking success. The browser UI uses Bootstrap 5 for baseline responsiveness and a custom CSS system for the premium light-blue SaaS visual language. JavaScript handles drag-and-drop, file selection, conversion progress, theme switching, history refresh, and result states.

## Project structure

- `app.py`: Flask routes, SQLite initialization, upload lifecycle, API orchestration, and error handling.
- `config.py`: environment-driven paths, upload limits, supported extensions, and application settings.
- `converters/`: focused real conversion functions for PDF, images, documents, spreadsheets, and FFmpeg media.
- `utils/file_validator.py`: extension and target validation.
- `utils/file_manager.py`: job folders, safe file naming, ZIP creation, and cleanup helpers.
- `templates/`: dashboard, tools catalog, history view, and shared layout.
- `static/css/style.css`: visual system, responsive layout, light/dark theme, motion, and components.
- `static/js/script.js`: browser-side interaction and API integration.
- `requirements.txt`, `.env.example`, `README.md`: installation and operation documentation.

## Design direction

### Style options considered

- **Cloudline Utility** (0.05): restrained white canvas, blue system accents, precise utility controls.
- **Night-shift SaaS** (0.06): dark-first interface, electric cyan accents, dense operational panels.
- **Editorial Conversion Desk** (0.04): warm neutral canvas, oversized type, magazine-like sections.

### Chosen style: Cloudline Utility

- **Design movement:** premium productivity SaaS, borrowing the confidence of CloudConvert and the clarity of modern developer tools.
- **Core principles:** calm hierarchy, visible progress, compact utility, and generous breathing room.
- **Color philosophy:** white and cool mist-blue make file handling feel safe and orderly; one vivid azure accent owns actions and progress; navy ink provides reliable contrast.
- **Layout paradigm:** a persistent left rail anchors the product while the working canvas stacks a hero action zone, recent activity, and capability groups; key actions stay close to the primary content edge rather than centered in generic marketing grids.
- **Signature elements:** a sky-blue upload stage with dotted perimeter, compact file chips with source-to-target arrows, and small uppercase section labels that make the interface feel instrument-like.
- **Interaction philosophy:** every action confirms state immediately; upload, target selection, progress, success, and errors have distinct visual language and never rely on hidden magic.
- **Animation:** short ease-out fades, subtle lift on hover, and a moving progress sheen; no looping distraction except the conversion activity indicator.
- **Typography system:** `DM Sans` for interface copy and `Space Grotesk` for headings, with tabular numerals for file sizes and counts.
- **Brand essence:** the fast, transparent conversion desk for people who need files to move without friction. Personality: precise, reassuring, capable.
- **Brand voice:** concise and confident. Example lines: “Drop the file. We’ll handle the rest.” and “Your conversion desk, without the busywork.”
- **Wordmark & logo:** a rounded square containing two offset arrows that form a subtle C, paired with the ConvertPro wordmark.
- **Signature brand color:** `#2F6BFF`, a clear azure that reads as action without feeling alarmist.
