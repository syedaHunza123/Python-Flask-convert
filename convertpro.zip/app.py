import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, redirect, render_template, request, send_from_directory, url_for
from werkzeug.exceptions import RequestEntityTooLarge
from werkzeug.utils import secure_filename

from config import DATABASE_PATH, MAX_UPLOAD_BYTES, OUTPUT_ROOT, SECRET_KEY, TOOLS, TOOL_BY_ID, UPLOAD_ROOT
from converters.document_converter import docx_to_html, docx_to_pdf, docx_to_txt, txt_to_docx
from converters.excel_converter import csv_to_xlsx, xlsx_to_csv, xlsx_to_html
from converters.image_converter import compress_image, convert_image, resize_image
from converters.media_converter import media_convert
from converters.pdf_converter import (
    compress_pdf,
    images_to_pdf,
    merge_pdfs,
    office_to_pdf,
    pdf_to_image,
    pdf_to_text,
    pdf_to_word,
    rotate_pdf,
    split_pdf,
)
from utils.file_manager import cleanup_expired_jobs, create_job_folder, output_path, remove_job, safe_input_path, zip_outputs
from utils.file_validator import validate_file_signature, validate_for_tool

app = Flask(__name__)
app.config.update(
    SECRET_KEY=SECRET_KEY,
    MAX_CONTENT_LENGTH=MAX_UPLOAD_BYTES,
    JSON_SORT_KEYS=False,
)

UPLOAD_ROOT.mkdir(parents=True, exist_ok=True)
OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)


def db_connection():
    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def initialize_database():
    with db_connection() as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS conversions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id TEXT NOT NULL,
                original_filename TEXT NOT NULL,
                source_format TEXT NOT NULL,
                target_format TEXT NOT NULL,
                file_size INTEGER NOT NULL,
                status TEXT NOT NULL,
                output_names TEXT NOT NULL DEFAULT '[]',
                error_message TEXT,
                created_at TEXT NOT NULL
            )
            """
        )
        connection.commit()


def record_conversion(**data):
    with db_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO conversions
            (job_id, original_filename, source_format, target_format, file_size, status, output_names, error_message, created_at)
            VALUES (:job_id, :original_filename, :source_format, :target_format, :file_size, :status, :output_names, :error_message, :created_at)
            """,
            data,
        )
        connection.commit()
        return cursor.lastrowid


def human_size(size: int) -> str:
    units = ["B", "KB", "MB", "GB"]
    value = float(size)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
        value /= 1024
    return f"{size} B"


def row_to_dict(row):
    item = dict(row)
    item["output_names"] = json.loads(item.get("output_names") or "[]")
    item["file_size_label"] = human_size(item["file_size"])
    item["created_at_label"] = datetime.fromisoformat(item["created_at"]).astimezone().strftime("%b %d, %Y · %H:%M")
    item["download_urls"] = [url_for("download_file", job_id=item["job_id"], filename=name) for name in item["output_names"]]
    return item


def convert_one(input_path: Path, output_dir: Path, tool: dict) -> list[Path]:
    tool_id = tool["id"]
    target = tool["target"]
    extension = input_path.suffix.lstrip(".") if target == "same" else target
    output = output_path(output_dir, input_path.name, extension)

    if tool_id == "pdf-to-word":
        pdf_to_word(input_path, output)
        return [output]
    if tool_id == "word-to-pdf":
        return [office_to_pdf(input_path, output_dir)]
    if tool_id in {"pdf-to-jpg", "pdf-to-png"}:
        return pdf_to_image(input_path, output_dir, target)
    if tool_id == "pdf-to-text":
        pdf_to_text(input_path, output)
        return [output]
    if tool_id == "pdf-split":
        return split_pdf(input_path, output_dir)
    if tool_id == "pdf-compress":
        compress_pdf(input_path, output)
        return [output]
    if tool_id == "pdf-rotate":
        rotate_pdf(input_path, output)
        return [output]
    if tool_id == "image-to-pdf":
        images_to_pdf([input_path], output)
        return [output]
    if tool_id in {"jpg-to-png", "png-to-jpg", "webp-to-jpg", "jpg-to-webp", "bmp-to-png", "tiff-to-jpg"}:
        convert_image(input_path, output, target)
        return [output]
    if tool_id == "image-resize":
        resize_image(input_path, output)
        return [output]
    if tool_id == "image-compress":
        compress_image(input_path, output)
        return [output]
    if tool_id == "docx-to-txt":
        docx_to_txt(input_path, output)
        return [output]
    if tool_id == "txt-to-docx":
        txt_to_docx(input_path, output)
        return [output]
    if tool_id == "docx-to-html":
        docx_to_html(input_path, output)
        return [output]
    if tool_id == "docx-to-pdf":
        return [docx_to_pdf(input_path, output_dir)]
    if tool_id == "xlsx-to-csv":
        xlsx_to_csv(input_path, output)
        return [output]
    if tool_id == "csv-to-xlsx":
        csv_to_xlsx(input_path, output)
        return [output]
    if tool_id == "xlsx-to-html":
        xlsx_to_html(input_path, output)
        return [output]
    if tool_id == "video-compress":
        media_convert(input_path, output, target, compress=True)
        return [output]
    if tool_id in {"mp3-to-wav", "wav-to-mp3", "mp4-to-mp3", "mov-to-mp4", "mkv-to-mp4", "webm-to-mp4"}:
        media_convert(input_path, output, target)
        return [output]
    raise ValueError("This conversion is not implemented yet.")


@app.context_processor
def inject_shell_data():
    return {"tools": TOOLS}


@app.route("/")
def index():
    return render_template("index.html", active_page="dashboard")


@app.route("/tools")
def tools_page():
    return render_template("tools.html", active_page="tools")


@app.route("/history")
def history_page():
    return render_template("history.html", active_page="history")


@app.get("/health")
def health():
    return jsonify({"ok": True, "service": "convertpro"})


@app.get("/manus-routes.json")
def routes_manifest():
    return jsonify({
        "routes": [
            {"path": "/", "title": "ConvertPro Dashboard"},
            {"path": "/tools", "title": "Converter Tools"},
            {"path": "/history", "title": "Conversion History"},
        ]
    })


@app.get("/api/tools")
def api_tools():
    return jsonify({"tools": TOOLS})


@app.get("/api/history")
def api_history():
    with db_connection() as connection:
        rows = connection.execute("SELECT * FROM conversions ORDER BY id DESC LIMIT 50").fetchall()
    return jsonify({"items": [row_to_dict(row) for row in rows]})


@app.delete("/api/history/<int:conversion_id>")
def delete_history(conversion_id: int):
    with db_connection() as connection:
        row = connection.execute("SELECT * FROM conversions WHERE id = ?", (conversion_id,)).fetchone()
        if not row:
            return jsonify({"error": "Conversion record not found."}), 404
        connection.execute("DELETE FROM conversions WHERE id = ?", (conversion_id,))
        connection.commit()
    remove_job(row["job_id"])
    return jsonify({"ok": True})


@app.post("/api/convert")
def convert_files():
    tool_id = request.form.get("tool_id", "")
    tool = TOOL_BY_ID.get(tool_id)
    files = request.files.getlist("files")
    if not tool:
        return jsonify({"error": "Choose a supported conversion tool first."}), 400
    if not files or all(not file.filename for file in files):
        return jsonify({"error": "Add at least one file to convert."}), 400

    job_id, input_dir, output_dir = create_job_folder()
    results = []
    output_files = []
    now = datetime.now(timezone.utc).isoformat()

    if tool_id == "pdf-merge":
        saved_paths = []
        original_names = []
        total_size = 0
        try:
            for file in files:
                if not file.filename:
                    continue
                original_name = secure_filename(file.filename) or "upload.pdf"
                validate_for_tool(original_name, tool_id)
                input_path = safe_input_path(input_dir, original_name)
                file.save(input_path)
                validate_file_signature(input_path, Path(original_name).suffix.lower().lstrip("."))
                saved_paths.append(input_path)
                original_names.append(original_name)
                total_size += input_path.stat().st_size
            if not saved_paths:
                raise ValueError("Add at least one PDF to merge.")
            merged = output_path(output_dir, "merged.pdf", "pdf")
            merge_pdfs(saved_paths, merged)
            output_files.append(merged)
            record_id = record_conversion(job_id=job_id, original_filename=f"{len(original_names)} PDFs merged", source_format="pdf", target_format="pdf", file_size=total_size, status="success", output_names=json.dumps([merged.name]), error_message=None, created_at=now)
            results.append({"id": record_id, "filename": f"{len(original_names)} PDFs", "status": "success", "outputs": [{"name": merged.name, "url": url_for("download_file", job_id=job_id, filename=merged.name)}]})
        except Exception as exc:
            results.append({"id": None, "filename": "PDF merge", "status": "error", "error": str(exc) or "The PDFs could not be merged."})
        return jsonify({"ok": any(item["status"] == "success" for item in results), "job_id": job_id, "results": results, "zip_url": None})

    for file in files:
        if not file.filename:
            continue
        original_name = secure_filename(file.filename) or "upload"
        input_path = None
        try:
            source_format, _ = validate_for_tool(original_name, tool_id)
            input_path = safe_input_path(input_dir, original_name)
            file.save(input_path)
            validate_file_signature(input_path, source_format)
            size = input_path.stat().st_size
            generated = convert_one(input_path, output_dir, tool)
            output_files.extend(generated)
            output_names = [path.name for path in generated]
            record_id = record_conversion(
                job_id=job_id,
                original_filename=original_name,
                source_format=source_format,
                target_format=tool["target"],
                file_size=size,
                status="success",
                output_names=json.dumps(output_names),
                error_message=None,
                created_at=now,
            )
            results.append({
                "id": record_id,
                "filename": original_name,
                "status": "success",
                "outputs": [{"name": name, "url": url_for("download_file", job_id=job_id, filename=name)} for name in output_names],
            })
        except Exception as exc:
            message = str(exc) or "This file could not be converted."
            try:
                source_format = Path(original_name).suffix.lower().lstrip(".") or "unknown"
                size = input_path.stat().st_size if input_path and input_path.exists() else 0
                record_id = record_conversion(
                    job_id=job_id,
                    original_filename=original_name,
                    source_format=source_format,
                    target_format=tool["target"],
                    file_size=size,
                    status="error",
                    output_names="[]",
                    error_message=message,
                    created_at=now,
                )
            except Exception:
                record_id = None
            results.append({"id": record_id, "filename": original_name, "status": "error", "error": message})

    zip_url = None
    if len(output_files) > 1:
        archive = zip_outputs(job_id, output_files)
        zip_url = url_for("download_file", job_id=job_id, filename=archive.name)

    is_success = any(item["status"] == "success" for item in results)
    return jsonify({"ok": is_success, "job_id": job_id, "results": results, "zip_url": zip_url}), (200 if is_success else 422)


@app.get("/download/<job_id>/<path:filename>")
def download_file(job_id: str, filename: str):
    job_dir = OUTPUT_ROOT / job_id
    if not job_dir.exists() or Path(filename).name != filename:
        return jsonify({"error": "Download not found."}), 404
    with db_connection() as connection:
        allowed = connection.execute(
            "SELECT 1 FROM conversions WHERE job_id = ? AND output_names LIKE ? LIMIT 1",
            (job_id, f"%{filename}%"),
        ).fetchone()
    if not allowed and not filename.startswith(f"convertpro-{job_id[:8]}"):
        return jsonify({"error": "Download not authorized."}), 403
    return send_from_directory(job_dir, filename, as_attachment=True)


@app.errorhandler(RequestEntityTooLarge)
def request_too_large(_error):
    return jsonify({"error": f"That upload is larger than the {human_size(MAX_UPLOAD_BYTES)} limit."}), 413


@app.errorhandler(404)
def not_found(error):
    if request.path.startswith("/api/") or request.path.startswith("/download/"):
        return jsonify({"error": "Not found."}), 404
    return render_template("index.html", active_page="dashboard"), 404


initialize_database()
cleanup_expired_jobs()

if __name__ == "__main__":
    port = int(os.getenv("PORT", "3000"))
    app.run(host="0.0.0.0", port=port, debug=os.getenv("FLASK_DEBUG", "0") == "1")
