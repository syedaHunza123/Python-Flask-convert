(() => {
  const qs = (selector, root = document) => root.querySelector(selector);
  const qsa = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const fileInput = qs('#fileInput');
  const dropZone = qs('#dropZone');
  const selectedFiles = qs('#selectedFiles');
  const toolSelect = qs('#toolSelect');
  const convertForm = qs('#convertForm');
  const toastStack = qs('#toastStack');
  let selected = [];

  const formatBytes = (bytes) => {
    if (!bytes) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB'];
    const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
    return `${(bytes / Math.pow(1024, index)).toFixed(index ? 1 : 0)} ${units[index]}`;
  };

  const escapeHtml = (value) => String(value ?? '').replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[char]));

  const notify = (message, type = '') => {
    if (!toastStack) return;
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    toastStack.appendChild(toast);
    window.setTimeout(() => toast.remove(), 3600);
  };

  const setTheme = (theme) => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem('convertpro-theme', theme);
  };
  setTheme(localStorage.getItem('convertpro-theme') || 'light');
  qs('#themeToggle')?.addEventListener('click', () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'));

  qs('#mobileMenu')?.addEventListener('click', () => qs('#sidebar')?.classList.toggle('open'));
  qsa('.sidebar .nav-item').forEach((link) => link.addEventListener('click', () => qs('#sidebar')?.classList.remove('open')));

  const renderFiles = () => {
    if (!selectedFiles) return;
    selectedFiles.innerHTML = selected.map((file, index) => {
      const ext = file.name.split('.').pop()?.toUpperCase() || 'FILE';
      return `<div class="file-chip"><span class="file-chip-icon">${escapeHtml(ext.slice(0, 4))}</span><span class="file-chip-name">${escapeHtml(file.name)}</span><span class="file-chip-size">${formatBytes(file.size)}</span><button type="button" class="file-chip-remove" data-file-index="${index}" aria-label="Remove ${escapeHtml(file.name)}">×</button></div>`;
    }).join('');
    qsa('.file-chip-remove', selectedFiles).forEach((button) => button.addEventListener('click', () => {
      selected.splice(Number(button.dataset.fileIndex), 1);
      renderFiles();
    }));
  };

  const addFiles = (files) => {
    const incoming = Array.from(files || []);
    const unique = incoming.filter((file) => !selected.some((current) => current.name === file.name && current.size === file.size));
    selected = selected.concat(unique);
    renderFiles();
    if (unique.length) notify(`${unique.length} file${unique.length > 1 ? 's' : ''} ready to convert.`);
  };

  qs('#browseButton')?.addEventListener('click', () => fileInput?.click());
  fileInput?.addEventListener('change', (event) => addFiles(event.target.files));
  ['dragenter', 'dragover'].forEach((eventName) => dropZone?.addEventListener(eventName, (event) => { event.preventDefault(); dropZone.classList.add('is-dragging'); }));
  ['dragleave', 'drop'].forEach((eventName) => dropZone?.addEventListener(eventName, (event) => { event.preventDefault(); dropZone.classList.remove('is-dragging'); }));
  dropZone?.addEventListener('drop', (event) => addFiles(event.dataTransfer.files));
  dropZone?.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') fileInput?.click(); });

  const selectTool = (toolId) => {
    if (!toolSelect) {
      localStorage.setItem('convertpro-tool', toolId);
      window.location.href = '/#converter';
      return;
    }
    toolSelect.value = toolId;
    qs('#converter')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    toolSelect.focus();
  };
  qsa('[data-tool-id]').forEach((card) => card.addEventListener('click', () => selectTool(card.dataset.toolId)));
  const storedTool = localStorage.getItem('convertpro-tool');
  if (storedTool && toolSelect && toolSelect.querySelector(`option[value="${CSS.escape(storedTool)}"]`)) {
    toolSelect.value = storedTool;
    localStorage.removeItem('convertpro-tool');
  }

  convertForm?.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!selected.length) { notify('Add at least one file before converting.', 'error'); dropZone?.focus(); return; }
    const button = qs('#convertButton');
    const progressPanel = qs('#progressPanel');
    const progressBar = qs('#progressBar');
    const progressLabel = qs('#progressLabel');
    const progressValue = qs('#progressValue');
    const resultPanel = qs('#resultPanel');
    const formData = new FormData();
    formData.append('tool_id', toolSelect.value);
    selected.forEach((file) => formData.append('files', file));
    button.disabled = true;
    resultPanel.hidden = true;
    progressPanel.hidden = false;
    let progress = 8;
    progressBar.style.width = `${progress}%`;
    progressValue.textContent = `${progress}%`;
    progressLabel.textContent = 'Uploading your files…';
    const progressTimer = window.setInterval(() => {
      progress = Math.min(progress + Math.ceil(Math.random() * 11), 88);
      progressBar.style.width = `${progress}%`;
      progressValue.textContent = `${progress}%`;
      progressLabel.textContent = progress > 46 ? 'Converting with care…' : 'Uploading your files…';
    }, 250);
    try {
      const response = await fetch('/api/convert', { method: 'POST', body: formData });
      const payload = await response.json();
      window.clearInterval(progressTimer);
      progressBar.style.width = '100%'; progressValue.textContent = '100%'; progressLabel.textContent = payload.ok ? 'Conversion complete.' : 'Conversion needs attention.';
      resultPanel.hidden = false;
      const successful = payload.results?.filter((item) => item.status === 'success') || [];
      const errors = payload.results?.filter((item) => item.status === 'error') || [];
      if (!response.ok && !payload.ok) throw new Error(payload.error || 'The conversion could not be completed.');
      let resultHtml = `<div class="result-title"><span>✓</span> ${successful.length ? `${successful.length} conversion${successful.length > 1 ? 's' : ''} ready` : 'Conversion finished with notes'}</div>`;
      if (errors.length) resultHtml += `<div>${errors.map((item) => `${escapeHtml(item.filename)}: ${escapeHtml(item.error)}`).join('<br>')}</div>`;
      const links = successful.flatMap((item) => item.outputs || []);
      if (payload.zip_url) links.push({ name: 'Download all as ZIP', url: payload.zip_url });
      if (links.length) resultHtml += `<div class="result-links">${links.map((link) => `<a class="download-link" href="${escapeHtml(link.url)}">↓ ${escapeHtml(link.name)}</a>`).join('')}</div>`;
      resultPanel.innerHTML = resultHtml;
      if (successful.length) { notify('Your converted file is ready.'); loadHistory(); }
    } catch (error) {
      window.clearInterval(progressTimer);
      progressPanel.hidden = true;
      resultPanel.hidden = false;
      resultPanel.classList.add('error');
      resultPanel.innerHTML = `<div class="result-title"><span>!</span> Conversion couldn’t finish</div><div>${escapeHtml(error.message)}</div>`;
      notify(error.message, 'error');
    } finally {
      button.disabled = false;
    }
  });

  const historyMarkup = (items, compact = false) => {
    if (!items.length) return '<div class="empty-state"><span class="empty-icon">↺</span><strong>No conversions yet</strong><p>Your latest files will appear here once you convert something.</p></div>';
    if (compact) return items.slice(0, 5).map((item) => [
      '<div class="activity-row"><span class="activity-file-icon">', escapeHtml(item.source_format.toUpperCase().slice(0, 4)),
      '</span><div><span class="activity-name">', escapeHtml(item.original_filename),
      '</span><span class="activity-sub">', escapeHtml(item.source_format.toUpperCase()), ' → ', escapeHtml(item.target_format.toUpperCase()), ' · ', escapeHtml(item.file_size_label),
      '</span></div><span class="activity-meta">', escapeHtml(item.created_at_label),
      '</span><span class="status-badge ', item.status === 'error' ? 'error' : '', '">', item.status === 'error' ? 'Error' : 'Ready',
      '</span><a class="activity-download" href="', item.download_urls?.[0] || '#', '">', item.download_urls?.length ? 'Download' : '—', '</a></div>'
    ].join('')).join('');
    const rows = items.map((item) => [
      '<div class="history-row"><div class="history-file"><span class="activity-file-icon">', escapeHtml(item.source_format.toUpperCase().slice(0, 4)),
      '</span><div><strong title="', escapeHtml(item.original_filename), '">', escapeHtml(item.original_filename), '</strong><small>', escapeHtml(item.file_size_label), ' · ', item.output_names?.length || 0, ' output', item.output_names?.length === 1 ? '' : 's',
      '</small></div></div><span class="history-cell">', escapeHtml(item.source_format.toUpperCase()), '</span><span class="history-cell">', escapeHtml(item.target_format.toUpperCase()), '</span><span class="history-cell">', escapeHtml(item.created_at_label),
      '</span><a class="history-output" href="', item.download_urls?.[0] || '#', '">', item.download_urls?.length ? 'Download' : item.status === 'error' ? 'Error' : '—',
      '</a><button class="delete-history" type="button" data-history-id="', item.id, '" aria-label="Delete ', escapeHtml(item.original_filename), '">×</button></div>'
    ].join('')).join('');
    return '<div class="history-header"><span>FILE</span><span>FROM</span><span>TO</span><span>DATE</span><span></span></div>' + rows;
  };

  const loadHistory = async () => {
    const targets = [qs('#recentActivity'), qs('#historyTable')].filter(Boolean);
    if (!targets.length) return;
    try {
      const response = await fetch('/api/history');
      const payload = await response.json();
      const items = payload.items || [];
      if (qs('#recentActivity')) qs('#recentActivity').innerHTML = historyMarkup(items, true);
      if (qs('#historyTable')) { qs('#historyTable').innerHTML = historyMarkup(items, false); qs('#historyCount').textContent = `${items.length} saved conversion${items.length === 1 ? '' : 's'}`; attachDeleteHandlers(); }
    } catch (_) {
      targets.forEach((target) => { target.innerHTML = '<div class="empty-state"><strong>History is unavailable</strong><p>Refresh the page to try again.</p></div>'; });
    }
  };

  const attachDeleteHandlers = () => qsa('.delete-history').forEach((button) => button.addEventListener('click', async () => {
    if (!window.confirm('Delete this history record and its generated files?')) return;
    const response = await fetch(`/api/history/${button.dataset.historyId}`, { method: 'DELETE' });
    if (response.ok) { notify('History record deleted.'); loadHistory(); } else notify('That record could not be deleted.', 'error');
  }));
  qs('#refreshHistory')?.addEventListener('click', loadHistory);
  loadHistory();

  qsa('.faq-item').forEach((button) => button.addEventListener('click', () => {
    button.classList.toggle('open');
    button.nextElementSibling?.classList.toggle('open');
  }));
})();
