# ConvertPro – All-in-One File Converter

A modular Flask application for converting common documents, images, spreadsheets, PDFs, audio, and video files. The interface is designed as a calm SaaS-style conversion desk with drag-and-drop upload, conversion progress, results, and SQLite history.

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python app.py
```

Open `http://127.0.0.1:3000`.

For audio/video support, install FFmpeg and make sure `ffmpeg` is on `PATH`. DOCX/PDF conversion through LibreOffice requires a headless LibreOffice installation. The app detects missing optional runtime dependencies and reports a clear error instead of returning a fake file.

## Supported conversion families

PDF workflows include PDF to Word, PDF to JPG or PNG, PDF to text, image to PDF, merge, split, rotate, and compression. Image workflows include JPG, PNG, WEBP, BMP, and TIFF conversion plus resize and compression through Pillow. Document workflows include DOCX to TXT, HTML, or PDF and TXT to DOCX. Spreadsheet workflows include XLSX to CSV or HTML and CSV to XLSX. Media workflows include MP3 to WAV, WAV to MP3, MP4 to MP3, MOV/MKV/WEBM to MP4, and compressed video output through FFmpeg.

The dashboard currently exposes 32 focused workflows. The server validates file extensions and common binary signatures, creates unique per-job workspaces, avoids duplicate output names in a batch, and removes temporary job folders older than 24 hours on application startup. History deletion removes the record and its generated files immediately.

## Production notes

Set a strong `SECRET_KEY`, keep `uploads/` and `outputs/` outside public static directories, and place the app behind a production WSGI server. The current starter includes a SQLite history layer for local deployments and a modular data access seam for later migration to a managed database.

For a container deployment, use the included `Dockerfile`; it installs FFmpeg, LibreOffice, Python dependencies, and runs Gunicorn on `$PORT` with `/health` as the readiness endpoint.
