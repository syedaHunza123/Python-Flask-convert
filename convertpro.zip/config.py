import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_ROOT = BASE_DIR / "uploads"
OUTPUT_ROOT = BASE_DIR / "outputs"
DATABASE_PATH = BASE_DIR / "convertpro.db"
MAX_UPLOAD_BYTES = int(os.getenv("MAX_CONTENT_LENGTH", str(100 * 1024 * 1024)))
SECRET_KEY = os.getenv("SECRET_KEY", "convertpro-local-development-key")

ALLOWED_EXTENSIONS = {
    "pdf", "docx", "txt", "html", "csv", "xlsx",
    "jpg", "jpeg", "png", "webp", "bmp", "tiff", "tif",
    "mp3", "wav", "mp4", "mov", "mkv", "webm",
}

TOOLS = [
    {"id": "pdf-to-word", "label": "PDF to Word", "category": "Document", "source": ["pdf"], "target": "docx", "icon": "DOC"},
    {"id": "word-to-pdf", "label": "Word to PDF", "category": "Document", "source": ["docx"], "target": "pdf", "icon": "PDF"},
    {"id": "pdf-to-jpg", "label": "PDF to JPG", "category": "PDF", "source": ["pdf"], "target": "jpg", "icon": "IMG"},
    {"id": "pdf-to-png", "label": "PDF to PNG", "category": "PDF", "source": ["pdf"], "target": "png", "icon": "IMG"},
    {"id": "pdf-to-text", "label": "PDF to Text", "category": "PDF", "source": ["pdf"], "target": "txt", "icon": "TXT"},
    {"id": "pdf-merge", "label": "Merge PDF", "category": "PDF", "source": ["pdf"], "target": "pdf", "icon": "PDF"},
    {"id": "pdf-split", "label": "Split PDF", "category": "PDF", "source": ["pdf"], "target": "pdf", "icon": "PDF"},
    {"id": "pdf-compress", "label": "Compress PDF", "category": "PDF", "source": ["pdf"], "target": "pdf", "icon": "PDF"},
    {"id": "pdf-rotate", "label": "Rotate PDF", "category": "PDF", "source": ["pdf"], "target": "pdf", "icon": "PDF"},
    {"id": "jpg-to-png", "label": "JPG to PNG", "category": "Image", "source": ["jpg", "jpeg"], "target": "png", "icon": "IMG"},
    {"id": "png-to-jpg", "label": "PNG to JPG", "category": "Image", "source": ["png"], "target": "jpg", "icon": "IMG"},
    {"id": "webp-to-jpg", "label": "WEBP to JPG", "category": "Image", "source": ["webp"], "target": "jpg", "icon": "IMG"},
    {"id": "jpg-to-webp", "label": "JPG to WEBP", "category": "Image", "source": ["jpg", "jpeg"], "target": "webp", "icon": "IMG"},
    {"id": "bmp-to-png", "label": "BMP to PNG", "category": "Image", "source": ["bmp"], "target": "png", "icon": "IMG"},
    {"id": "tiff-to-jpg", "label": "TIFF to JPG", "category": "Image", "source": ["tiff", "tif"], "target": "jpg", "icon": "IMG"},
    {"id": "image-resize", "label": "Resize Image", "category": "Image", "source": ["jpg", "jpeg", "png", "webp", "bmp", "tiff", "tif"], "target": "same", "icon": "IMG"},
    {"id": "image-compress", "label": "Compress Image", "category": "Image", "source": ["jpg", "jpeg", "png", "webp", "bmp", "tiff", "tif"], "target": "same", "icon": "IMG"},
    {"id": "image-to-pdf", "label": "Image to PDF", "category": "PDF", "source": ["jpg", "jpeg", "png", "webp", "bmp", "tiff"], "target": "pdf", "icon": "PDF"},
    {"id": "docx-to-txt", "label": "DOCX to TXT", "category": "Document", "source": ["docx"], "target": "txt", "icon": "TXT"},
    {"id": "txt-to-docx", "label": "TXT to DOCX", "category": "Document", "source": ["txt"], "target": "docx", "icon": "DOC"},
    {"id": "docx-to-html", "label": "DOCX to HTML", "category": "Document", "source": ["docx"], "target": "html", "icon": "WEB"},
    {"id": "docx-to-pdf", "label": "DOCX to PDF", "category": "Document", "source": ["docx"], "target": "pdf", "icon": "PDF"},
    {"id": "xlsx-to-csv", "label": "XLSX to CSV", "category": "Spreadsheet", "source": ["xlsx"], "target": "csv", "icon": "CSV"},
    {"id": "csv-to-xlsx", "label": "CSV to XLSX", "category": "Spreadsheet", "source": ["csv"], "target": "xlsx", "icon": "XLS"},
    {"id": "xlsx-to-html", "label": "XLSX to HTML", "category": "Spreadsheet", "source": ["xlsx"], "target": "html", "icon": "WEB"},
    {"id": "mp3-to-wav", "label": "MP3 to WAV", "category": "Media", "source": ["mp3"], "target": "wav", "icon": "AUD"},
    {"id": "wav-to-mp3", "label": "WAV to MP3", "category": "Media", "source": ["wav"], "target": "mp3", "icon": "AUD"},
    {"id": "mp4-to-mp3", "label": "MP4 to MP3", "category": "Media", "source": ["mp4", "mov", "mkv", "webm"], "target": "mp3", "icon": "VID"},
    {"id": "mov-to-mp4", "label": "MOV to MP4", "category": "Media", "source": ["mov"], "target": "mp4", "icon": "VID"},
    {"id": "mkv-to-mp4", "label": "MKV to MP4", "category": "Media", "source": ["mkv"], "target": "mp4", "icon": "VID"},
    {"id": "webm-to-mp4", "label": "WEBM to MP4", "category": "Media", "source": ["webm"], "target": "mp4", "icon": "VID"},
    {"id": "video-compress", "label": "Compress Video", "category": "Media", "source": ["mp4", "mov", "mkv", "webm"], "target": "mp4", "icon": "VID"},
]

TOOL_BY_ID = {tool["id"]: tool for tool in TOOLS}
